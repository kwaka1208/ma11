
/* 設定 */
//var SERVER_URL = "http://163.221.14.161:3500/sabori";
//  SERVER_URL = "http://163.221.14.161:3500/gomi";
//var SERVER_URL = "./Action_http.json";
var SERVER_URL = "./action1.json";
var WEBSOCKET_URL = "ws://localhost:8888";
//var WEBSOCKET_SERVER_URL = "ws://192.168.10.81:5000";     //市川さんURL
var WEBSOCKET_SERVER_URL = "ws://192.168.10.89:5000";     //市川さんURL

var debug = true;
var debug_local = true;
var timeout_id = null;

function start_polling(){
    if(timeout_id === null){
        timeout_id = setTimeout(fetchServer, 10000);    // 10秒後にサーバーをチェック
        console.log("start_polling");
    }
    else{
        clearTimeout(timeout_id);
        timeout_id = null;
        console.log("stop_polling");
    }
}

function fetchServer() {
	$.ajax({
		url: SERVER_URL,
		dataType: "json",
		cache: false,
		success: function(data){
//						$("#output").append(data);
		poke_json(data);
		timeout_id = setTimeout(fetchServer, 10000);	// 10秒間隔でサーバーをチェック
	    },
		error: function(data){
		//				$("#output").append("読み込み失敗<br />");
            console.log("fetch error");
		}
	});
}

function poke_json(data) {

//    if(typeof data === "undefined") return;
    
    var num = 0;

/*
    if(debug_local){

        num = Math.floor((Math.random() * 100) % data.length);
        console.log("num = " + num);
        console.log("data.length = " + data.length);
    }
*/
/*
        for ( num = 0; num < data.length; num++){
            if(data[num].Action == "Say"){
                saytext(data[num].Txt);
            }
            else{
                someAction(data[num].Action);
            } 
        }
*/

/* 
    if(data[num].Action == "Say"){
        saytext(data[num].Txt);
    }
    else{
        someAction(data[num].Action);
    }
*/

    if(data.Action == "Say"){
        saytext(data.Txt);
    }
    else{
        someAction(data.Action);
    }
}

function poke(string){
    var json_obj;

	console.log("string = " + string );

	if(typeof string === "undefined") return;

	json_obj = JSON.parse(string);
    poke_json(json_obj);

}


// しゃべられる
function saytext(text){
    if (text == "") return;

//		$("res").innerHTML += toHTML("Pepper say " + text + " now.<br>");
		console.log("Pepper say " + text + ".");
        
        // 表示★★★★ここここここここここここここここここ
        
        //しゃべる
        playText(text);


//		session.service("ALMemory").done(function (ALMemory) {
//		ALMemory.raiseEvent("PepperQiMessaging/fromtablet", text);
//	});

}

// 動き
function someAction(action){
    changeImage(action);
    
	if (debug) {
		console.log(action);
		if(typeof action != "undefined"){
//			$("res").innerHTML += toHTML("Pepper do " + action + " now.<br>");
			console.log("Pepper do " + action + ".");
		}
	}else {
//		session.service("ALMemory").done(function (ALMemory) {
//		ALMemory.raiseEvent("PepperQiAction/fromtablet",action);
//	});
	}
}


/* ========================================================== */
/*  websocket                                                 */
/* ========================================================== */
var ws = null;

function start_websocket(){
    
    if(ws){ //websocket接続状態で再度押下されたら切断
        
        console.log("websocket close");
        ws.onclose();
        return;
    }

    ws = new WebSocket(WEBSOCKET_SERVER_URL);
    console.log("start websocket");
    
    //メッセージ受信した時 (これをfunctionの中に入れて良いかなぁ～。。。)
    ws.onmessage = function(e){

//      $("res").innerHTML += toHTML(e.data) + "<br>";
        console.log("websocket onmessage");
//        console.log(e.data);
//        poke_json(e.data);
        poke(e.data);
    };

    
}





/* ========================================================== */
/*  Utility                                                   */
/* ========================================================== */

// 画像変更
var counter = 0;
function changeImage(action){
	var image = "images/" + action + "_1" + ".GIF";
//				$("#output").append(image);
//	$("img").attr("src", image);
    
    document.getElementById('init_img').style["display"] = "none";
            
    document.getElementById('kekka').src = image;
    document.getElementById('kekka').style["display"] = "inline";
    
}

var media = null;
var mediaTimer = null;



function playAudio(url) {
    // URL のオーディオファイルを再生。参考⇒ http://docs.monaca.mobi/2.9/ja/reference/phonegap_29/ja/media/media/
    
    console.log("playAudio url = " + url);
    
    if(url == null) return;
    
    
    var my_media = new Media(url,
        // 呼び出し成功
        function() {
            console.log("playAudio():Audio Success");
        },
        // 呼び出し失敗
        function(err) {
            console.log("playAudio():Audio Error: "+err);
            
//            my_media.stop();
            my_media.release();
        },
        function(mediaStatus){
            console.log("mediaStatus=" + mediaStatus);  //NONE=0, STARTING=1, RUNNING=2, PAUSED=3, STOPPED=4
            if( mediaStatus == 4 ){
//                fs_remove("foo.wav");
                my_media.release();

            }

    });

    // オーディオ再生
    if(my_media)    my_media.play();
}


////////////////////
function playText(string){
   
   var VOICE_URL = "https://api.apigw.smt.docomo.ne.jp/voiceText/v1/textToSpeech?APIKEY=436a68634567577842527458767736356e2e2f5279497249347738397043545a495243794c6c4564785930";
   
    var xmlHttpRequest = new XMLHttpRequest();
    xmlHttpRequest.onreadystatechange = function(){
        var READYSTATE_COMPLETED = 4;   // 0=UNSENT, 1=OPENDED, 2=HEADER_RECEIVED, 3=LOADING 
        var HTTP_STATUS_OK = 200;

        if( this.readyState == READYSTATE_COMPLETED ){
            if( this.status == HTTP_STATUS_OK ){
            
            console.log("GET response");

            var arrayBuffer = xmlHttpRequest.response;
//            var content-type = xmlHttpRequest.getResponseHeader("Content-Type");

            
            if (arrayBuffer) {
                console.log("binary get!");
                console.log("arrayBuffer = " + arrayBuffer);
                console.log("arrayBuffer.byteLength = " + arrayBuffer.byteLength);


     
                fsdemo03write(arrayBuffer);
                playAudio("//foo.wav"); 
                
            }
            
            }   //status == HTTP_STATUS_OK
            else{
                console.log("http status = " + this.status );
//                console.log(xmlHttpRequest.getAllResponseHeaders());
            }

        }
    };

    xmlHttpRequest.open( 'POST', VOICE_URL );
    xmlHttpRequest.setRequestHeader( 'Content-Type', 'application/x-www-form-urlencoded' );
    xmlHttpRequest.responseType = 'arraybuffer';
//    xmlHttpRequest.responseType = "blob";
    
    var post_body = "text=" + string + "&speaker=haruka";
//    var post_body = "text=なんでやねん&speaker=haruka";
    xmlHttpRequest.send( post_body );
    

    console.log("POST_REQUEST");

}    


///////////////////


function ChangeImgRandom(){
            
    var dice = Math.floor(Math.random() * 3);
    var img;
            
    switch( dice ){
        case 0:dice
            img = "images/pepper_1_normal.jpg";
            break;
                    
        case 1:dice
            img = "images/pepper_2_angry.jpg";
            break;
                    
        case 2:dice
            img = "images/pepper_3_smile.jpg";
            break;
    }
            
    document.getElementById('init_img').style["display"] = "none";
            
    document.getElementById('kekka').src = img;
    document.getElementById('kekka').style["display"] = "inline";
}
        
        



function next_page(){
    console.log("next page");
    document.location.href = "next.html";
}


function random(){
    var dice = Math.floor(Math.random() * 10 % 3);
    
    
        console.log(dice);

        if (dice == 2) {
            next_page();
        }else{
            // don't care.
        }
        
}

function EncodeHTMLForm( data ){
    var params = [];

    for( var name in data )
    {
        var value = data[ name ];
        var param = encodeURIComponent( name ) + '=' + encodeURIComponent( value );

        params.push( param );
    }

    return params.join( '&' ).replace( /%20/g, '+' );
}


//function fsdemo02write(arrayData) {
function fsdemo02write() {  
    console.log( "file = " + cordova.file.cacheDirectory + "foo.wav" );
                        
    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, 
        function(fs){
            fs.root.getFile(cordova.file.cacheDirectory + "foo.txt", {create: true}, 
//            fs.root.getFile("foo.wav", {create:true, exclusive:false},
                function(fileEntry) {
                    console.log( "file = " + foo.wav );
                    
                    console.log("fullpath=" + fileEntry.fullPath);
                    fileEntry.createWriter(
                        function(writer) {
                            writer.onwrite = function(evt) { console.log("success"); }
                            writer.write("Hello");
//                                write.write(arrayData);

                                

                        },
                        function(fileError) { console.log("fileEntry.createWriter = " + fileError.code); }
                        );
                }, 
                function(fileError) { console.log("fileEntryError2 = " + fileError.code); }   //ここでエラー！　ENCODING_ERR=5
                );
        }, 
        function(fileError) { console.log("requestFileSystem Error " + fileError.code); }
        );
}



function fsdemo03write(arrayData) {
    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, 
        function(fs){
            fs.root.getFile("foo.wav", {create: true}, 
                function(fileEntry) {
                    console.log("fullpath=" + fileEntry.fullPath);
                    fileEntry.createWriter(
                        function(writer) {
                            writer.onwrite = function(evt) { console.log("success"); }
                            writer.write(arrayData);
                        },
                        function(fileError) { alert(fileError.code); }
                        );
                }, 
                function(fileError) { alert(fileError.code); }
                );
        }, 
        function(fileError) { alert(fileError.code); }
        );
}



function fs_remove(filename) {
    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, 
        function(fs){
            fs.root.getFile(filename, {create: true}, 
                function(fileEntry) {
                    console.log("fullpath=" + fileEntry.fullPath);
                    fileEntry.remove(
                        function(entry) {
                            console.log("success to remove file.");
                        },
                        function(fileError) { console.log("fileError.code" = + fileError.code); }
                        );
                }, 
                function(fileError) { alert(fileError.code); }
                );
        }, 
        function(fileError) { alert(fileError.code); }
        );
}

function readfile2array(filename) { //return=arraybuffer
    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, 
        function(fs){
            console.log("filename=" + filename);
            fs.root.getFile(filename, {create: false},
                function(fileEntry) {
                    console.log("fullpath=" + fileEntry.fullPath);

                    fileEntry.file(
                        function(file){     // fileEntry.file == Success

                            var reader = new FileReader();
                            reader.onloadend = function (evt) {
                                console.log("read success");
                                console.log(new Uint8Array(evt.target.result)); //★★★return
                            };
                            reader.readAsArrayBuffer(file);
                            
                        },
                        
                        function(evt){ console.log("file read error = " + error.code); }
                            
                            
                            
                    );
                        
                        
/*
                    fileEntry.createWriter(
                        function(writer) {
                            writer.onwrite = function(evt) { console.log("success"); }
                            writer.write("Hello");
                        },
                        function(fileError) { console.log(fileError.code); }
                        );
*/
                        
                }, 
                function(fileError) { console.log("file entry errorcode" + fileError.code); }   //ここでエラー発生
                );
        }, 
        function(fileError) { console.log("file system errorcode"+ fileError.code); }
        );
}





function getPath() {
    var str = location.pathname;
    var i = str.lastIndexOf('/');
    return str.substring(0,i+1);
}
        
/* ========================= Power API ======================= */
function judege_Power(){
   
   var VOICE_URL = "https://api.apigw.smt.docomo.ne.jp/voiceText/v1/textToSpeech?APIKEY=436a68634567577842527458767736356e2e2f5279497249347738397043545a495243794c6c4564785930";
   
    var xmlHttpRequest = new XMLHttpRequest();
    xmlHttpRequest.onreadystatechange = function(){
        var READYSTATE_COMPLETED = 4;   // 0=UNSENT, 1=OPENDED, 2=HEADER_RECEIVED, 3=LOADING 
        var HTTP_STATUS_OK = 200;

        if( this.readyState == READYSTATE_COMPLETED ){
            if( this.status == HTTP_STATUS_OK ){
            
            console.log("GET response");

            var arrayBuffer = xmlHttpRequest.response;
//            var content-type = xmlHttpRequest.getResponseHeader("Content-Type");

            
            if (arrayBuffer) {
                console.log("binary get!");
                console.log("arrayBuffer = " + arrayBuffer);
                console.log("arrayBuffer.byteLength = " + arrayBuffer.byteLength);


// 検証１。本命案。サーバーから受信したwaveファイルをblob形式でURLにして再生　⇒再生エラー
// テストとしてサーバー上のURL指定でファイル再生やローカルファイル指定でのファイル再生では音鳴動する。

/*                 
                var byteArray = new Uint8Array(arrayBuffer);
                var blob = new Blob([byteArray], { "type" : "audio/wave" });

                var SPEECH_URL = window.URL || window.webkitURL;
                
                

                playAudio(SPEECH_URL.createObjectURL(blob));
                
                //playAudio("http://audio.ibeat.org/content/p1rj1s/p1rj1s_-_rockGuitar.mp3");　//ネット上のファイル再生⇒再生成功
                //playAudio(getPath() + 'pause.wav'); 　//ローカルファイルの再生⇒再生成功
*/                
// 検証１。ここまで。検証１。ここまで。検証１。ここまで。検証１。ここまで。          
                
                
// 検証２。サーバーから受信したwaveファイルが悪いかの切り分けのためにファイル保存　⇒ファイル保存エラー。

//                fsdemo02write(arrayBuffer); //正確にはfileEntry作成エラー発生
//                    fsdemo02write();
                    fsdemo03write(arrayBuffer);
                    playAudio("//foo.wav"); 
                
                //http://uhyohyo.net/javascript/12_5.html  基本
                //http://www.glamenv-septzen.net/view/1044
                
                // メモ⇒ http://tech-sketch.jp/2013/01/javascript-1.html

                
//                readfile2array(getPath() + 'pause.wav');
//                readfile2array("pause.wav");
                //playAudio(getPath() + 'pause.wav'); 
                
                
                //https://docs.oracle.com/javase/jp/6/jre/api/plugin/dom/constant-values.html#org.w3c.dom.DOMException.NOT_FOUND_ERR
            }
            
            }   //status == HTTP_STATUS_OK
            else{
                console.log("http status = " + this.status );
//                console.log(xmlHttpRequest.getAllResponseHeaders());
            }

        }
    };





    xmlHttpRequest.open( 'POST', VOICE_URL );
    xmlHttpRequest.setRequestHeader( 'Content-Type', 'application/x-www-form-urlencoded' );
    xmlHttpRequest.responseType = 'arraybuffer';
//    xmlHttpRequest.responseType = "blob";
    
    var post_body = "text=なんでやねん&speaker=haruka";
    xmlHttpRequest.send( post_body );
    

    console.log("POST_REQUEST");

   
   
/*    
	var POWER_URL = "http://setsuden.yahooapis.jp/v1/Setsuden/latestPowerUsage?appid=dj0zaiZpPXZjdGtaTEkyMkFYVyZzPWNvbnN1bWVyc2VjcmV0Jng9ZDY-&output=json&area=kansai"; 
        $.getJSON(POWER_URL, function(json){
            console.log(json.ElectricPowerUsage.Area);
            console.log(json.ElectricPowerUsage.Date);
            console.log(json.ElectricPowerUsage.Usage.$);
            console.log(json.ElectricPowerUsage.Capacity.$);
            
            if( json.ElectricPowerUsage.Usage.$ / json.ElectricPowerUsage.Capacity.$ > 0.5 ){
                console.log("over 50%");
                
            document.getElementById('init_img').style["display"] = "none";
            document.getElementById('kekka').src = "images/pepper_3_smile.jpg";
            document.getElementById('kekka').style["display"] = "inline";
            }


	})
*/

}    
/* ========================= Power API ここまで========================== */

/* ========================= Weather API ======================== */
function getWeather(){
        
	var WEATHER_URL = "http://api.yumake.jp/1.0/forecastPref.php?code=29&key=6ec397cd3fe4c98f99e35dfe14793e8&format=json"; 
        
        $.getJSON(WEATHER_URL, function(json){
            console.log(json.title);
            console.log(json.area[0].areaName);
            console.log(json.area[0].weather[2]);
            console.log(json.area[1].windDirection[2]);
            console.log(json.temperartureDateName[3]);
        })
}    
/* ========================= Weather API ここまで ====================== */

